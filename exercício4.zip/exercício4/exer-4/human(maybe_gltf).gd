extends Node3D

@onready var animation_tree = $AnimationTree
@onready var playback: AnimationNodeStateMachinePlayback = animation_tree.get("parameters/playback")

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("anim1"):
		playback.travel("idle")
	if event.is_action_pressed("anim2"):
		playback.travel("salsa")
	if event.is_action_pressed("anim3"):
		playback.travel("silly")
